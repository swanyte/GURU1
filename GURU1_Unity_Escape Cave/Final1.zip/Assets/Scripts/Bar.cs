﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bar : MonoBehaviour
{
    
    Vector3 origin;
    Vector3 MovePositionRight;
    Vector3 MovePositionLeft;

    // Start is called before the first frame update
    void Start()
    {
        origin = transform.position;
        MovePositionRight = origin + Vector3.right * 2;
        MovePositionLeft= origin + Vector3.left * 2;
    }

    float currentTime = 0;
    float openTime = 1;

    public void BarMoveRight()
    {
        currentTime += Time.deltaTime;
        transform.position = Vector3.Lerp(origin, MovePositionRight, 200);
    }
    public void BarMoveLeft()
    {
        currentTime += Time.deltaTime;
        transform.position = Vector3.Lerp(origin, MovePositionLeft, 200);
    }
    // Update is called once per frame
    void Update()
    {

    }


}
