﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class firedie : MonoBehaviour
{
    private void Awake()
    {
        gameOverUI.SetActive(false);
    }
    public GameObject gameOverUI;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Water")
        {
            // collision.gameObject.SetActive(false);
            Destroy(this.gameObject);
            if (gameOverUI.activeSelf == false)
            {
                gameOverUI.SetActive(true);
                AudioSource aknkh = gameOverUI.GetComponent<AudioSource>();
                aknkh.Play();
            }
        }

    }
   
}
