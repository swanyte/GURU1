﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public GameObject ButtonRstart;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (DoorB.Instance.ready && DoorR.Instance.ready)
        {
            SceneManager.LoadScene("two");
        }
    }
    
    public void PlaySE()
    {
        AudioSource buttonsound = ButtonRstart.GetComponent<AudioSource>();
        buttonsound.Play();
    }
    public void OnClickRestart()
    {

        SceneManager.LoadScene(0);
    }
}
